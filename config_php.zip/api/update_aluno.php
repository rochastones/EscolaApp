<?php

// UPDATE ALUNO - Atualizar aluno
// Verifica se o aluno pertence ao usuário

require_once 'auth.php';
require_once '../config/database.php';

// 1. VALIDA TOKEN
$userId = validarToken();

// 2. RECEBE DADOS
$data = json_decode(file_get_contents("php://input"));


// 3. VALIDA DADOS
if (!isset($data->id) || empty($data->id)) {
    http_response_code(400);
    echo json_encode(['error' => 'ID do aluno não fornecido']);
    exit;
}

// 4. CONECTA AO BANCO
$database = new Database();
$db = $database->getConnection();

// 5. VERIFICA SE ALUNO PERTENCE AO USUÁRIO
$checkQuery = "SELECT id FROM alunos WHERE id = :id AND user_id = :user_id";
$checkStmt = $db->prepare($checkQuery);
$checkStmt->bindParam(':id', $data->id);
$checkStmt->bindParam(':user_id', $userId);
$checkStmt->execute();

if ($checkStmt->rowCount() === 0) {
    http_response_code(403);
    echo json_encode(['error' => 'Aluno não encontrado ou não pertence a você']);
    exit;
}

// 6. ATUALIZA ALUNO
$query = "UPDATE alunos SET 
          nomeAluno = :nomeAluno,
          nomeProfessor = :nomeProfessor,
          disciplina = :disciplina,
          nota = :nota,
          statusAprovacao = :statusAprovacao
          WHERE id = :id AND user_id = :user_id";

$stmt = $db->prepare($query);

$stmt->bindParam(':id', $data->id);
$stmt->bindParam(':nomeAluno', $data->nomeAluno);
$stmt->bindParam(':nomeProfessor', $data->nomeProfessor);
$stmt->bindParam(':disciplina', $data->disciplina);
$stmt->bindParam(':nota', $data->nota);
$stmt->bindParam(':statusAprovacao', $data->statusAprovacao);
$stmt->bindParam(':user_id', $userId);

// 7. EXECUTA
if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Aluno atualizado com sucesso'
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao atualizar aluno'
    ]);
}
?>
