<?php

// LOGIN AUTH - Gera Token JWT
// Este endpoint recebe o UID do Firebase Auth
// e retorna um token JWT para uso na API

require_once 'jwt_helper.php';


// RECEBE DADOS DA REQUISIÇÃO
$data = json_decode(file_get_contents("php://input"));

// VALIDA DADOS RECEBIDOS
if (!isset($data->uid) || empty($data->uid)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'UID do usuário não fornecido'
    ]);
    exit;
}

if (!isset($data->email) || empty($data->email)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Email do usuário não fornecido'
    ]);
    exit;
}

// GERA TOKEN JWT
$payload = [
    'userId' => $data->uid,
    'email' => $data->email
];

$token = gerarJWT($payload);

// RETORNA TOKEN
echo json_encode([
    'success' => true,
    'token' => $token,
    'userId' => $data->uid,
    'email' => $data->email,
    'expiresIn' => TOKEN_EXPIRY
]);
?>