<?php

// AUTENTICAÇÃO - Validação de Token

// Este arquivo valida o token JWT enviado
// pelo aplicativo em cada requisição

require_once 'jwt_helper.php';

// FUNÇÃO: Valida Token

// Verifica o token e retorna o userId se válido
// Caso contrário, retorna erro 401

function validarToken() {
    // Busca o cabeçalho Authorization
    $headers = getallheaders();
    $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';
    
    // Extrai o token do formato "Bearer token"
    $token = null;
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } elseif (!empty($authHeader)) {
        // Suporte para token direto (sem Bearer)
        $token = $authHeader;
    }
    
    // Verifica se o token foi fornecido
    if (empty($token)) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Token não fornecido. Faça login primeiro.'
        ]);
        exit;
    }
    
    // Valida o token
    $payload = validarJWT($token);
    if (!$payload) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Token inválido ou expirado. Faça login novamente.'
        ]);
        exit;
    }
    
    // Retorna o userId do token
    return $payload['userId'];
}

// FUNÇÃO: Valida Token e retorna em caso de erro
// verificação simples sem interromper
function verificarToken() {
    try {
        return validarToken();
    } catch (Exception $e) {
        return null;
    }
}
?>