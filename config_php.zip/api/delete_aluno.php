<?php

// DELETE ALUNO - Remover aluno
// Verifica se o aluno pertence ao usuário
require_once 'auth.php';
require_once '../config/database.php';

// 1. VALIDA TOKEN
$userId = validarToken();

// 2. RECEBE ID
$id = isset($_GET['id']) ? $_GET['id'] : null;

if (empty($id)) {
    http_response_code(400);
    echo json_encode(['error' => 'ID do aluno não fornecido']);
    exit;
}

// 3. CONECTA AO BANCO
$database = new Database();
$db = $database->getConnection();

// 4. VERIFICA SE ALUNO PERTENCE AO USUÁRIO
$checkQuery = "SELECT id FROM alunos WHERE id = :id AND user_id = :user_id";
$checkStmt = $db->prepare($checkQuery);
$checkStmt->bindParam(':id', $id);
$checkStmt->bindParam(':user_id', $userId);
$checkStmt->execute();

if ($checkStmt->rowCount() === 0) {
    http_response_code(403);
    echo json_encode(['error' => 'Aluno não encontrado ou não pertence a você']);
    exit;
}

// 5. DELETA ALUNO
$query = "DELETE FROM alunos WHERE id = :id AND user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->bindParam(':user_id', $userId);

// 6. EXECUTA
if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Aluno deletado com sucesso'
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao deletar aluno'
    ]);
}
?>