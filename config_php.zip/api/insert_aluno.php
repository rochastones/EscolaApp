<?php

// INSERT ALUNO - Adiciona novo aluno
// Associa o aluno ao usuário autenticado
require_once 'auth.php';
require_once '../config/database.php';

// 1. VALIDA TOKEN
$userId = validarToken();

// 2. RECEBE DADOS
$data = json_decode(file_get_contents("php://input"));

// 3. VALIDA DADOS
if (!isset($data->id) || !isset($data->nomeAluno)) {
    http_response_code(400);
    echo json_encode(['error' => 'Dados incompletos']);
    exit;
}

// 4. CONECTA AO BANCO
$database = new Database();
$db = $database->getConnection();

// 5. INSERI ALUNO COM USER_ID
$query = "INSERT INTO alunos (id, nomeAluno, nomeProfessor, disciplina, nota, statusAprovacao, user_id) 
          VALUES (:id, :nomeAluno, :nomeProfessor, :disciplina, :nota, :statusAprovacao, :user_id)";

$stmt = $db->prepare($query);

$stmt->bindParam(':id', $data->id);
$stmt->bindParam(':nomeAluno', $data->nomeAluno);
$stmt->bindParam(':nomeProfessor', $data->nomeProfessor);
$stmt->bindParam(':disciplina', $data->disciplina);
$stmt->bindParam(':nota', $data->nota);
$stmt->bindParam(':statusAprovacao', $data->statusAprovacao);
$stmt->bindParam(':user_id', $userId);  // USA O USER_ID DO TOKEN

// 6. EXECUTA
if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Aluno inserido com sucesso'
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao inserir aluno'
    ]);
}
?>