<?php

// CONFIGURAÇÕES GLOBAIS DA API
// contém todas as configurações necessárias para o funcionamento da API

// CHAVE SECRETA PARA JWT
//Esta chave deve ser única e secreta
//usa uma chave gerada aleatoriamente.
define('JWT_SECRET_KEY', 'escolaapp_secure_key_2024_!@#$%');

// ALGORITMO DE ASSINATURA
define('JWT_ALGORITHM', 'HS256');

// TEMPO DE EXPIRAÇÃO DO TOKEN (em segundos)
define('TOKEN_EXPIRY', 3600); // 1 hora

// CONFIGURAÇÕES DO BANCO DE DADOS
define('DB_HOST', 'localhost');
define('DB_NAME', 'escola_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// HEADERS CORS (Permiti requisições do app)
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Responde requisições OPTIONS (pré-flight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
?>