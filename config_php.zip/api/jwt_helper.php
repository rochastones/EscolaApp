<?php

// JWT HELPER - Funções para JWT
// Este arquivo contém as funções para:
// - Gerar token JWT
// - Validar token JWT
// - Codificar/Decodificar Base64Url

require_once 'config.php';

// FUNÇÃO: Codifica Base64Url
// Converte dados para Base64Url (seguro para URLs)
function base64UrlEncode($data) {
    return str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($data));
}

// FUNÇÃO: Decodifica Base64Url
// Converte Base64Url de volta para dados originais
function base64UrlDecode($data) {
    return base64_decode(str_replace(['-', '_'], ['+', '/'], $data));
}

// FUNÇÃO: Gera JWT
// Cria um novo token JWT com os dados do usuário
function gerarJWT($payload) {
    // Header do token
    $header = [
        'alg' => JWT_ALGORITHM,
        'typ' => 'JWT'
    ];
    
    // Payload com timestamps
    $payload['iat'] = time(); 
    $payload['exp'] = time() + TOKEN_EXPIRY; 
    
    // Codifica header e payload
    $headerEncoded = base64UrlEncode(json_encode($header));
    $payloadEncoded = base64UrlEncode(json_encode($payload));
    
    // Gera assinatura
    $signature = hash_hmac(
        'sha256',
        "$headerEncoded.$payloadEncoded",
        JWT_SECRET_KEY,
        true
    );
    $signatureEncoded = base64UrlEncode($signature);
    
    // Monta o token completo
    return "$headerEncoded.$payloadEncoded.$signatureEncoded";
}

// FUNÇÃO: Valida JWT
// Verifica se o token é válido e retorna os dados
function validarJWT($token) {
    // Divide o token em partes
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return null;
    }
    
    list($headerEncoded, $payloadEncoded, $signatureEncoded) = $parts;
    
    // Verifica assinatura
    $signature = base64UrlDecode($signatureEncoded);
    $expectedSignature = hash_hmac(
        'sha256',
        "$headerEncoded.$payloadEncoded",
        JWT_SECRET_KEY,
        true
    );
    
    if (!hash_equals($signature, $expectedSignature)) {
        return null;
    }
    
    // Decodifica payload
    $payload = json_decode(base64UrlDecode($payloadEncoded), true);
    if (!$payload) {
        return null;
    }
    
    // Verifica expiração
    if (isset($payload['exp']) && $payload['exp'] < time()) {
        return null;
    }
    
    return $payload;
}
?>