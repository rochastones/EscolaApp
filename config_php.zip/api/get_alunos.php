<?php

// GET ALUNOS - Lista alunos do usuário
// Retorna apenas os alunos do usuário autenticado
require_once 'auth.php';
require_once '../config/database.php';

// 1. VALIDA TOKEN
$userId = validarToken();

// 2. CONECTA AO BANCO
$database = new Database();
$db = $database->getConnection();

// 3. BUSCA ALUNOS DO USUÁRIO
$query = "SELECT id, nomeAluno, nomeProfessor, disciplina, nota, statusAprovacao, user_id
          FROM alunos 
          WHERE user_id = :user_id 
          ORDER BY nomeAluno ASC";

$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $userId);
$stmt->execute();

$alunos = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    array_push($alunos, $row);
}

// 4. RETORNA RESULTADO
echo json_encode($alunos);
?>