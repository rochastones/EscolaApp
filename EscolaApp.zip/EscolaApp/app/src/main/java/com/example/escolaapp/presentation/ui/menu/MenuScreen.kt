package com.example.escolaapp.presentation.ui.menu

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.escolaapp.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    onNavigateToTransactions: () -> Unit,
    onNavigateToConfig: () -> Unit,
    onLogout: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("EscolaApp - Menu Principal") },
                actions = {
                    TextButton(
                        onClick = onLogout
                    ) {
                        Text("Sair", color = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
        ) {

            // LOGO ESCOLAAPP
            Card(
                modifier = Modifier
                    .width(220.dp)
                    .height(120.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo_escolaapp),
                    contentDescription = "Logo EscolaApp",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
            // SUBTÍTULO
            Text(
                text = "Plataforma Escolar Inteligente e Segura",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier.padding(bottom = 32.dp)
            )
            Button(
                onClick = onNavigateToTransactions,
                modifier = Modifier.width(250.dp)
            ) {
                Text("📚 Gerenciar Alunos")
            }

            Button(
                onClick = onNavigateToConfig,
                modifier = Modifier.width(250.dp)
            ) {
                Text("⚙️ Configurar Fonte de Dados")
            }

            Text(
                text = "O repositório ativo será usado para todas operações",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}