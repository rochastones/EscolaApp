package com.example.escolaapp.presentation.ui.transaction

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.escolaapp.domain.model.Aluno
import com.example.escolaapp.presentation.viewmodel.TransactionViewModel
import com.example.escolaapp.utils.DataSourceType
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionScreen(
    viewModel: TransactionViewModel,
    onBack: () -> Unit
) {
    val alunos by viewModel.alunos.collectAsStateWithLifecycle()
    val currentDataSource by viewModel.currentDataSource.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()


    // Observa mensagens do ViewModel
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    var showDialog by remember { mutableStateOf(false) }
    var alunoEmEdicao by remember { mutableStateOf<Aluno?>(null) }

    // Estado para confirmação de exclusão
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var alunoParaExcluir by remember { mutableStateOf<Aluno?>(null) }

    // Snackbar para mensagens de sucesso/erro
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Exibe mensagem do Snackbar quando chega do ViewModel
     LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearSnackbarMessage()
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gerenciar Alunos") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        alunoEmEdicao = null
                        showDialog = true
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Adicionar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Indicador da fonte atual
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when (currentDataSource) {
                            DataSourceType.ROOM -> MaterialTheme.colorScheme.tertiaryContainer
                            DataSourceType.API -> MaterialTheme.colorScheme.secondaryContainer
                            DataSourceType.FIREBASE -> MaterialTheme.colorScheme.primaryContainer
                        }
                    )
                ) {
                    Text(
                        text = "Usando: ${currentDataSource.name}",
                        modifier = Modifier.padding(8.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                // Lista de alunos
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(if (isLoading) Modifier.blur(4.dp) else Modifier),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(alunos) { aluno ->
                        TransactionItem(
                            aluno = aluno,
                            onEdit = {
                                alunoEmEdicao = aluno
                                showDialog = true
                            },
                            onDelete = {
                                alunoParaExcluir = aluno
                                showDeleteConfirmation = true
                            }
                        )
                    }
                }
            }
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(56.dp),
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 4.dp
                        )
                        Text(
                            text = "Salvando informacoes...",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Aguarde um momento",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
    // Confirmação de exclusão
    if (showDeleteConfirmation && alunoParaExcluir != null) {
        AlertDialog(
            onDismissRequest = {
                showDeleteConfirmation = false
                alunoParaExcluir = null
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            try {
                                alunoParaExcluir?.let { aluno ->
                                    viewModel.deleteAluno(aluno)
                                }
                            } catch (e: Exception) {
                                val mensagemErro = when {
                                    e.message?.contains("Network") == true || e.message?.contains("Internet") == true ->
                                        "Verifique sua conexao com a internet"
                                    e.message?.contains("Firebase") == true ->
                                        "Erro ao conectar com o Firebase"
                                    e.message?.contains("timeout") == true ->
                                        "Tempo de resposta excedido"
                                    else ->
                                        "Erro ao excluir: ${e.message}"
                                }
                                snackbarHostState.showSnackbar(mensagemErro)
                            } finally {
                                showDeleteConfirmation = false
                                alunoParaExcluir = null
                            }
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Excluir")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmation = false
                        alunoParaExcluir = null
                    }
                ) {
                    Text("Cancelar")
                }
            },
            title = { Text("Excluir Aluno") },
            text = { Text("Deseja realmente excluir este aluno?") }
        )
    }
    // Adição e edição
    if (showDialog) {
        AddAlunoDialog(
            aluno = alunoEmEdicao,
            onDismiss = {
                showDialog = false
                alunoEmEdicao = null
            },
            onSave = { aluno ->
                scope.launch {
                    try {
                        if (alunoEmEdicao == null) {
                            viewModel.addAluno(aluno)
                        } else {
                            viewModel.updateAluno(aluno)
                        }
                    } catch (e: Exception) {
                        // Mensagem caso o ViewModel não capture o erro
                        snackbarHostState.showSnackbar("Erro ao salvar: ${e.message}")
                    } finally {
                        showDialog = false
                        alunoEmEdicao = null
                    }
                }
            }
        )
    }
}

@Composable
fun AddAlunoDialog(
    aluno: Aluno? = null,
    onDismiss: () -> Unit,
    onSave: (Aluno) -> Unit
) {
    var nomeAluno by remember { mutableStateOf(aluno?.nomeAluno ?: "") }
    var nomeProfessor by remember { mutableStateOf(aluno?.nomeProfessor ?: "") }
    var disciplina by remember { mutableStateOf(aluno?.disciplina ?: "") }
    var nota by remember { mutableStateOf(aluno?.nota?.toString() ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val notaDouble = nota.toDoubleOrNull() ?: 0.0
                    onSave(
                        Aluno(
                            id = aluno?.id ?: java.util.UUID.randomUUID().toString(),
                            nomeAluno = nomeAluno,
                            nomeProfessor = nomeProfessor,
                            disciplina = disciplina,
                            nota = notaDouble,
                            statusAprovacao = Aluno.calcularStatus(notaDouble)
                        )
                    )
                }
            ) {
                Text(if (aluno == null) "Adicionar" else "Salvar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        },
        title = { Text(if (aluno == null) "Adicionar Aluno" else "Editar Aluno") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = nomeAluno,
                    onValueChange = { nomeAluno = it },
                    label = { Text("Nome do Aluno") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nomeProfessor,
                    onValueChange = { nomeProfessor = it },
                    label = { Text("Professor") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = disciplina,
                    onValueChange = { disciplina = it },
                    label = { Text("Disciplina") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nota,
                    onValueChange = { nota = it },
                    label = { Text("Nota") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    )
}