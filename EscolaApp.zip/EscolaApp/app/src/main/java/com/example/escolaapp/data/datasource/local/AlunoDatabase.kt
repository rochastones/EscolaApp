package com.example.escolaapp.data.datasource.local

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

@Database(entities = [AlunoEntity::class], version = 1, exportSchema = false)
abstract class AlunoDatabase : RoomDatabase() {
    abstract fun alunoDao(): AlunoDao

    companion object {
        @Volatile
        private var INSTANCE: AlunoDatabase? = null

        fun getInstance(context: Context): AlunoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AlunoDatabase::class.java,
                    "escola_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
