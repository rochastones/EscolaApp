package com.example.escolaapp.presentation.viewmodel

import kotlinx.coroutines.Job
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.escolaapp.domain.model.Aluno
import com.example.escolaapp.domain.repository.TransactionRepository
import com.example.escolaapp.utils.DataStoreManager
import com.example.escolaapp.utils.DataSourceType
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.util.Log

class TransactionViewModel(
    private val roomRepo: TransactionRepository,
    private val apiRepo: TransactionRepository,
    private val firebaseRepo: TransactionRepository,
    private val dataStoreManager: DataStoreManager
) : ViewModel() {

    companion object {
        private const val TAG = "TransactionVM"
    }

    private val _alunos = MutableStateFlow<List<Aluno>>(emptyList())
    val alunos = _alunos.asStateFlow()

    private val _currentDataSource = MutableStateFlow(DataSourceType.ROOM)
    val currentDataSource = _currentDataSource.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    // Estado para mensagens de erro/sucesso
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage = _snackbarMessage.asStateFlow()

    private var currentJob: Job? = null

    init {
        viewModelScope.launch {
            dataStoreManager.getDataSourceFlow().collect { type ->
                Log.d(TAG, "DataSource mudou para: ${type.name}")
                _currentDataSource.value = type
                switchRepository(type)
            }
        }
    }
    // Limpa mensagem após exibir
    fun clearSnackbarMessage() {
        _snackbarMessage.value = null
    }
    private fun switchRepository(type: DataSourceType) {
        Log.d(TAG, "switchRepository: ${type.name}")
        currentJob?.cancel()

        _isLoading.value = true
        Log.d(TAG, "switchRepository: loading ativado")

        val repo = when (type) {
            DataSourceType.ROOM -> roomRepo
            DataSourceType.API -> apiRepo
            DataSourceType.FIREBASE -> firebaseRepo
        }

        currentJob = repo.getAllAlunos()
            .onEach {
                Log.d(TAG, "switchRepository: dados recebidos, ${it.size} alunos")
                _alunos.value = it
                _isLoading.value = false
                Log.d(TAG, "switchRepository: loading desativado")
            }
            .catch { error ->
                Log.e(TAG, "switchRepository: ERRO - ${error.message}")
                _isLoading.value = false
            }
            .launchIn(viewModelScope)
    }

    fun updateAluno(aluno: Aluno) {
        Log.d(TAG, "updateAluno iniciado: ${aluno.nomeAluno}")
        viewModelScope.launch {
            try {
                _isLoading.value = true
                Log.d(TAG, "updateAluno: loading ativado")

                Log.d(TAG, "updateAluno: chamando getRepo().updateAluno()")
                getRepo().updateAluno(aluno)
                Log.d(TAG, "updateAluno: updateAluno() finalizado com sucesso")

                Log.d(TAG, "updateAluno: chamando refreshData()")
                refreshData()
                Log.d(TAG, "updateAluno: refreshData() finalizado")

                // Mensagem de sucesso
                _snackbarMessage.value = "Aluno atualizado com sucesso!"

            } catch (e: Exception) {
                Log.e(TAG, "updateAluno: ERRO - ${e.message}")
                _isLoading.value = false
                Log.d(TAG, "updateAluno: loading desativado (apos erro)")

                // Mensagens de erro específicas
                val mensagem = when {
                    e.message?.contains("timeout") == true -> "Verifique sua conexao com a internet"
                    e.message?.contains("Firebase") == true -> "Erro ao conectar com o Firebase"
                    e.message?.contains("Network") == true -> "Sem conexão com a internet"
                    else -> "Erro ao salvar: ${e.message}"
                }
                _snackbarMessage.value = mensagem
            }
        }
    }
    fun addAluno(aluno: Aluno) {
        Log.d(TAG, "addAluno iniciado: ${aluno.nomeAluno}")
        viewModelScope.launch {
            try {
                _isLoading.value = true
                Log.d(TAG, "addAluno: loading ativado")

                getRepo().addAluno(aluno)
                Log.d(TAG, "addAluno: addAluno() finalizado")

                refreshData()
                Log.d(TAG, "addAluno: refreshData() finalizado")

                // Mensagem de sucesso
                _snackbarMessage.value = "Aluno cadastrado com sucesso!"

            } catch (e: Exception) {
                Log.e(TAG, "addAluno: ERRO - ${e.message}")
                _isLoading.value = false

                val mensagem = when {
                    e.message?.contains("timeout") == true -> "Verifique sua conexao com a internet"
                    e.message?.contains("Firebase") == true -> "Erro ao conectar com o Firebase"
                    e.message?.contains("Network") == true -> "Sem conexão com a internet"
                    else -> "Erro ao cadastrar: ${e.message}"
                }
                _snackbarMessage.value = mensagem
            }
        }
    }
    fun deleteAluno(aluno: Aluno) {
        Log.d(TAG, "deleteAluno iniciado: ${aluno.nomeAluno}")
        viewModelScope.launch {
            try {
                _isLoading.value = true
                Log.d(TAG, "deleteAluno: loading ativado")

                getRepo().deleteAluno(aluno)
                Log.d(TAG, "deleteAluno: deleteAluno() finalizado")

                refreshData()
                Log.d(TAG, "deleteAluno: refreshData() finalizado")

                // Mensagem de sucesso
                _snackbarMessage.value = "Aluno excluído com sucesso!"

            } catch (e: Exception) {
                Log.e(TAG, "deleteAluno: ERRO - ${e.message}")
                _isLoading.value = false

                val mensagem = when {
                    e.message?.contains("timeout") == true -> "Verifique sua conexao com a internet"
                    e.message?.contains("Firebase") == true -> "Erro ao conectar com o Firebase"
                    e.message?.contains("Network") == true -> "Sem conexão com a internet"
                    else -> "Erro ao excluir: ${e.message}"
                }
                _snackbarMessage.value = mensagem
            }
        }
    }

    fun changeDataSource(type: DataSourceType) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                dataStoreManager.saveDataSource(type)
            } catch (e: Exception) {
                _isLoading.value = false
                _snackbarMessage.value = "Erro ao mudar fonte de dados"
            }
        }
    }

    private fun getRepo(): TransactionRepository {
        val type = _currentDataSource.value
        Log.d(TAG, "getRepo: ${type.name}")
        return when (type) {
            DataSourceType.ROOM -> roomRepo
            DataSourceType.API -> apiRepo
            DataSourceType.FIREBASE -> firebaseRepo
        }
    }
    private fun refreshData() {
        Log.d(TAG, "refreshData iniciado")
        val currentType = _currentDataSource.value
        currentJob?.cancel()
        Log.d(TAG, "refreshData: currentJob cancelado")

        val repo = when (currentType) {
            DataSourceType.ROOM -> roomRepo
            DataSourceType.API -> apiRepo
            DataSourceType.FIREBASE -> firebaseRepo
        }

        currentJob = repo.getAllAlunos()
            .onEach {
                Log.d(TAG, "refreshData: dados recebidos, ${it.size} alunos")
                _alunos.value = it
                _isLoading.value = false
                Log.d(TAG, "refreshData: loading desativado")
            }
            .catch { error ->
                Log.e(TAG, "refreshData: ERRO - ${error.message}")
                _isLoading.value = false
            }
            .launchIn(viewModelScope)
    }
}