package com.example.escolaapp.data.di

import com.example.escolaapp.domain.repository.TransactionRepository
import com.example.escolaapp.domain.repository.AuthRepository
import com.example.escolaapp.data.repository.AuthRepositoryImpl
import com.example.escolaapp.presentation.ui.auth.AuthViewModel
import org.koin.core.qualifier.named
import com.example.escolaapp.data.datasource.firebase.FirestoreDataSource
import com.example.escolaapp.data.datasource.local.AlunoDao
import com.example.escolaapp.data.datasource.local.AlunoDatabase
import com.example.escolaapp.data.datasource.remote.AlunoApiService
import com.example.escolaapp.data.datasource.remote.RetrofitClient
import com.example.escolaapp.data.mapper.AlunoMapper
import com.example.escolaapp.data.repository.TransactionRepositoryFirebaseImpl
import com.example.escolaapp.data.repository.TransactionRepositoryRemoteImpl
import com.example.escolaapp.data.repository.TransactionRepositoryRoomImpl
import com.example.escolaapp.presentation.viewmodel.TransactionViewModel
import com.example.escolaapp.utils.DataStoreManager
import com.example.escolaapp.utils.RepositoryProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseAuth
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {
    // Room
    single { AlunoDatabase.getInstance(androidContext()) }
    single<AlunoDao> { get<AlunoDatabase>().alunoDao() }

    // RETROFIT (inicializado com DataStore)
    single {
        RetrofitClient.init(get())  // Inicializa com DataStore
        RetrofitClient.instance
    }

    // Firebase
    single { FirebaseFirestore.getInstance() }
    single { FirebaseAuth.getInstance() }

    // Mapper
    single { AlunoMapper() }

    // Data Sources
    single { FirestoreDataSource(get(), get()) }

    // REPOSITORIES
    single<TransactionRepository>(named("room")) {
        TransactionRepositoryRoomImpl(get(), get())
    }

    single<TransactionRepository>(named("api")) {
        TransactionRepositoryRemoteImpl(get(), get())
    }

    single<TransactionRepository>(named("firebase")) {
        TransactionRepositoryFirebaseImpl(get())
    }

    // AUTH REPOSITORY
    // O AuthRepositoryImpl recebe o AlunoApiService
    single<AuthRepository> {
        AuthRepositoryImpl(
            auth = get(),
            dataStoreManager = get(),
            apiService = get()  // AlunoApiService para gerar token
        )
    }

    // UTILS
    single { DataStoreManager(androidContext()) }
    single { RepositoryProvider(get(), get(), get()) }

    // VIEWMODELS
    viewModel { AuthViewModel(get()) }

    viewModel {
        TransactionViewModel(
            roomRepo = get(named("room")),
            apiRepo = get(named("api")),
            firebaseRepo = get(named("firebase")),
            dataStoreManager = get()
        )
    }
}