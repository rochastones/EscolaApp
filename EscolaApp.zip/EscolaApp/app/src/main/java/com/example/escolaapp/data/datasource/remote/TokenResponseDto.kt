package com.example.escolaapp.data.datasource.remote

import com.google.gson.annotations.SerializedName

data class TokenResponseDto(
    @SerializedName("success")
    val success: Boolean = false,

    @SerializedName("token")
    val token: String = "",

    @SerializedName("userId")
    val userId: String = "",

    @SerializedName("email")
    val email: String = "",

    @SerializedName("expiresIn")
    val expiresIn: Int = 0,

    @SerializedName("error")
    val error: String? = null
)