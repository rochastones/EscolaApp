package com.example.escolaapp.data.datasource.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alunos")
data class AlunoEntity(
    @PrimaryKey
    val id: String,
    val nomeAluno: String,
    val nomeProfessor: String,
    val disciplina: String,
    val nota: Double,
    val statusAprovacao: String
)