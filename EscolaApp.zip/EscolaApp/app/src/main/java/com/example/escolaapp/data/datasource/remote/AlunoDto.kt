package com.example.escolaapp.data.datasource.remote

data class AlunoDto(
    val id: String,
    val nomeAluno: String,
    val nomeProfessor: String,
    val disciplina: String,
    val nota: Double,
    val statusAprovacao: String
)