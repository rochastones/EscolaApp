package com.example.escolaapp.data.repository

import com.example.escolaapp.data.datasource.remote.AlunoApiService
import com.example.escolaapp.data.mapper.AlunoMapper
import com.example.escolaapp.domain.model.Aluno
import com.example.escolaapp.domain.repository.TransactionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class TransactionRepositoryRemoteImpl(
    private val api: AlunoApiService,
    private val mapper: AlunoMapper
) : TransactionRepository {

    override fun getAllAlunos(): Flow<List<Aluno>> = flow {
        val alunos = api.getAlunos().map { mapper.toDomain(it) }
        emit(alunos)
    }.flowOn(Dispatchers.IO)

    override suspend fun addAluno(aluno: Aluno) {
        api.insertAluno(mapper.toDto(aluno))
    }

    override suspend fun updateAluno(aluno: Aluno) {
        api.updateAluno(mapper.toDto(aluno))
    }

    override suspend fun deleteAluno(aluno: Aluno) {
        api.deleteAluno(aluno.id)
    }
}