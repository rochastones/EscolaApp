package com.example.escolaapp.domain.model

data class Aluno(
    val id: String = java.util.UUID.randomUUID().toString(),
    val nomeAluno: String,
    val nomeProfessor: String,
    val disciplina: String,
    val nota: Double,
    val statusAprovacao: String
) {
    companion object {
        fun calcularStatus(nota: Double): String = if (nota >= 6.0) "Aprovado" else "Reprovado"
    }
}