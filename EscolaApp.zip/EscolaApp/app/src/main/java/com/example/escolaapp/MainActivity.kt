package com.example.escolaapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.escolaapp.presentation.navigation.NavGraph
import com.example.escolaapp.ui.theme.EscolaAppTheme
import org.koin.androidx.compose.koinViewModel
import com.example.escolaapp.presentation.ui.auth.AuthViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            EscolaAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    EscolaAppNav()
                }
            }
        }
    }
}

// NAVEGAÇÃO PRINCIPAL (com Navigation Compose)
@Composable
fun EscolaAppNav() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = koinViewModel()

    NavGraph(
        navController = navController,
        authViewModel = authViewModel
    )
}