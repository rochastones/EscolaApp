package com.example.escolaapp.data.repository

import com.example.escolaapp.data.datasource.remote.AlunoApiService
import com.example.escolaapp.data.datasource.remote.TokenResponseDto
import com.example.escolaapp.domain.model.User
import com.example.escolaapp.domain.repository.AuthRepository
import com.example.escolaapp.utils.DataStoreManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.userProfileChangeRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepositoryImpl @Inject constructor(
    private val auth: FirebaseAuth,
    private val dataStoreManager: DataStoreManager,
    private val apiService: AlunoApiService
) : AuthRepository {

    override fun getCurrentUser(): User? {
        return auth.currentUser?.toDomainUser()
    }

    override fun getAuthState(): Flow<User?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser?.toDomainUser()
            trySend(user)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    override suspend fun signIn(email: String, password: String): Result<User> {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            val firebaseUser = result.user
            val user = firebaseUser?.toDomainUser()

            if (user != null) {

                // APÓS LOGIN, GERA TOKEN JWT
                generateAndSaveToken(user)
                Result.success(user)
            } else {
                Result.failure(Exception("Erro ao fazer login"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun signUp(email: String, password: String, displayName: String): Result<User> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            val firebaseUser = result.user
            firebaseUser?.updateProfile(
                userProfileChangeRequest {
                    this.displayName = displayName
                }
            )?.await()

            val user = firebaseUser?.toDomainUser()
            if (user != null) {

                // APÓS CADASTRO, GERAR TOKEN JWT
                generateAndSaveToken(user)
                Result.success(user)
            } else {
                Result.failure(Exception("Erro ao criar conta"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun signOut() {
        auth.signOut()
        dataStoreManager.clearUserData()  // Limpa token ao sair
    }

    override suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            auth.sendPasswordResetEmail(email).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // GERA TOKEN JWT VIA API
    private suspend fun generateAndSaveToken(user: User) {
        try {
            val response = apiService.generateToken(
                mapOf(
                    "uid" to user.uid,
                    "email" to user.email
                )
            )

            if (response.isSuccessful) {
                val result = response.body()
                if (result?.success == true) {
                    dataStoreManager.saveToken(result.token)
                    dataStoreManager.saveUserId(user.uid)
                    dataStoreManager.saveUserEmail(user.email)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun FirebaseUser.toDomainUser(): User {
        return User(
            uid = uid,
            email = email ?: "",
            displayName = displayName
        )
    }
}