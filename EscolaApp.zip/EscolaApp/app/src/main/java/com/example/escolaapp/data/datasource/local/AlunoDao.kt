package com.example.escolaapp.data.datasource.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AlunoDao {
    @Query("SELECT * FROM alunos ORDER BY nomeAluno ASC")
    fun getAll(): Flow<List<AlunoEntity>>

    @Insert
    suspend fun insert(aluno: AlunoEntity)

    @Update
    suspend fun update(aluno: AlunoEntity)

    @Delete
    suspend fun delete(aluno: AlunoEntity)

    @Query("DELETE FROM alunos")
    suspend fun deleteAll()
}