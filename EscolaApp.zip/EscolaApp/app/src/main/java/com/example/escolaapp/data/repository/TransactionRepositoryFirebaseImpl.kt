package com.example.escolaapp.data.repository

import com.example.escolaapp.data.datasource.firebase.FirestoreDataSource
import com.example.escolaapp.domain.model.Aluno
import com.example.escolaapp.domain.repository.TransactionRepository
import kotlinx.coroutines.flow.Flow

class TransactionRepositoryFirebaseImpl(
    private val dataSource: FirestoreDataSource
) : TransactionRepository {

    override fun getAllAlunos(): Flow<List<Aluno>> {
        return dataSource.getAlunosFlow()
    }

    override suspend fun addAluno(aluno: Aluno) {
        dataSource.addAluno(aluno)
    }

    override suspend fun updateAluno(aluno: Aluno) {
        dataSource.updateAluno(aluno)
    }

    override suspend fun deleteAluno(aluno: Aluno) {
        dataSource.deleteAluno(aluno)
    }
}