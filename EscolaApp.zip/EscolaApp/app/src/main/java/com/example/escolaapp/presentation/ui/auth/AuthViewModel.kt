package com.example.escolaapp.presentation.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.escolaapp.domain.model.User
import com.example.escolaapp.domain.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    // ESTADO DE AUTENTICAÇÃO
    private val _authState = MutableStateFlow<User?>(null)
    val authState: StateFlow<User?> = _authState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.getAuthState().collect { user ->
                _authState.value = user
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun signIn(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = authRepository.signIn(email, password)
            result.onSuccess { onSuccess() }
                .onFailure { _errorMessage.value = it.message }
            _isLoading.value = false
        }
    }

    fun signUp(email: String, password: String, displayName: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = authRepository.signUp(email, password, displayName)
            result.onSuccess { onSuccess() }
                .onFailure { _errorMessage.value = it.message }
            _isLoading.value = false
        }
    }

    fun signOut(onSuccess: () -> Unit) {
        viewModelScope.launch {
            authRepository.signOut()
            onSuccess()
        }
    }

    fun resetPassword(email: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = authRepository.sendPasswordResetEmail(email)
            result.onSuccess {
                _errorMessage.value = "Email de recuperação enviado!"
                onSuccess()
            }.onFailure { _errorMessage.value = it.message }
            _isLoading.value = false
        }
    }
}