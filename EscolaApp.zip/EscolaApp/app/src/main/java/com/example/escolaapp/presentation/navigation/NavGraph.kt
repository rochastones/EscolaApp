package com.example.escolaapp.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.escolaapp.presentation.ui.auth.LoginScreen
import com.example.escolaapp.presentation.ui.auth.SignUpScreen
import com.example.escolaapp.presentation.ui.auth.AuthViewModel
import com.example.escolaapp.presentation.ui.config.ConfigScreen
import com.example.escolaapp.presentation.ui.menu.MenuScreen
import com.example.escolaapp.presentation.ui.transaction.TransactionScreen
import com.example.escolaapp.presentation.viewmodel.TransactionViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun NavGraph(
    navController: NavHostController,
    authViewModel: AuthViewModel = koinViewModel()
) {
    val authState = authViewModel.authState.collectAsState()
    val user = authState.value

    LaunchedEffect(user) {
        if (user != null) {
            navController.navigate(Screen.Menu.route) {
                popUpTo(Screen.Login.route) { inclusive = true }
                launchSingleTop = true
            }
        } else {
            navController.navigate(Screen.Login.route) {
                popUpTo(0) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = Screen.Login.route
    ) {
        composable(Screen.Login.route) {
            LoginScreen(
                authViewModel = authViewModel,
                onLoginSuccess = {
                    navController.navigate(Screen.Menu.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToSignUp = {
                    navController.navigate(Screen.SignUp.route)
                }
            )
        }

        composable(Screen.SignUp.route) {
            SignUpScreen(
                authViewModel = authViewModel,
                onSignUpSuccess = {
                    navController.navigate(Screen.Menu.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToLogin = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.SignUp.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(Screen.Menu.route) {

            MenuScreen(
                onNavigateToTransactions = {
                    navController.navigate(Screen.Transactions.route)
                },
                onNavigateToConfig = {
                    navController.navigate(Screen.Config.route)
                },
                onLogout = {
                    authViewModel.signOut {
                        navController.navigate(Screen.Login.route) {
                            popUpTo(Screen.Menu.route) { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        composable(Screen.Transactions.route) {
            val transactionViewModel: TransactionViewModel = koinViewModel()

            TransactionScreen(
                viewModel = transactionViewModel,
                onBack = {
                    navController.navigate(Screen.Menu.route) {
                        popUpTo(Screen.Transactions.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(Screen.Config.route) {
            val transactionViewModel: TransactionViewModel = koinViewModel()

            ConfigScreen(
                viewModel = transactionViewModel,
                onBack = {
                    navController.navigate(Screen.Menu.route) {
                        popUpTo(Screen.Config.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }
    }
}