package com.example.escolaapp.data.datasource.remote

import com.example.escolaapp.utils.DataStoreManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {
    private const val BASE_URL = "http://192.168.15.15/escolaapp/api/"

    private lateinit var dataStoreManager: DataStoreManager

    fun init(dataStore: DataStoreManager) {
        dataStoreManager = dataStore
    }

    private fun createAuthInterceptor(): Interceptor {
        return Interceptor { chain ->
            var request = chain.request()

            val token = try {
                dataStoreManager.getTokenSync()  //  método síncrono
            } catch (e: Exception) {
                null
            }

            token?.let {
                request = request.newBuilder()
                    .addHeader("Authorization", "Bearer $it")
                    .build()
            }

            chain.proceed(request)
        }
    }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .addInterceptor(createAuthInterceptor())
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    val instance: AlunoApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AlunoApiService::class.java)
    }
}