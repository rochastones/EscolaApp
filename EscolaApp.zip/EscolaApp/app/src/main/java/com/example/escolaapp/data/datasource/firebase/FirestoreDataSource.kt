package com.example.escolaapp.data.datasource.firebase

import com.google.firebase.firestore.FirebaseFirestore
import com.example.escolaapp.data.mapper.AlunoMapper
import com.example.escolaapp.domain.model.Aluno
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import kotlin.time.Duration.Companion.seconds

class FirestoreDataSource(
    private val firestore: FirebaseFirestore,
    private val mapper: AlunoMapper
) {
    private val collectionPath = "alunos"
    private val timeoutSeconds = 5.seconds

    fun getAlunosFlow(): Flow<List<Aluno>> = callbackFlow {
        val snapshotListener = firestore.collection(collectionPath)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val alunos = snapshot?.documents?.mapNotNull { doc ->
                    val dto = doc.toObject(AlunoFirestoreDto::class.java)
                    dto?.let { mapper.fromFirestoreDto(it) }
                } ?: emptyList()
                trySend(alunos)
            }
        awaitClose { snapshotListener.remove() }
    }

    suspend fun addAluno(aluno: Aluno) {
        try {
            withTimeout(timeoutSeconds) {
                val dto = mapper.toFirestoreDto(aluno)
                firestore.collection(collectionPath)
                    .document(aluno.id)
                    .set(dto)
                    .await()
            }
        } catch (_: TimeoutCancellationException) {
            throw Exception("timeout: Firebase demorou muito para responder. Verifique sua conexao.")
        } catch (_: Exception) {
            throw Exception("Firebase error")
        }
    }

    suspend fun updateAluno(aluno: Aluno) {
        try {
            withTimeout(timeoutSeconds) {
                val dto = mapper.toFirestoreDto(aluno)
                firestore.collection(collectionPath)
                    .document(aluno.id)
                    .set(dto)
                    .await()
            }
        } catch (_: TimeoutCancellationException) {
            throw Exception("timeout: Firebase demorou muito para responder. Verifique sua conexao.")
        } catch (_: Exception) {  // ← Corrigido: underscore
            throw Exception("Firebase error")
        }
    }

    suspend fun deleteAluno(aluno: Aluno) {
        try {
            withTimeout(timeoutSeconds) {
                firestore.collection(collectionPath)
                    .document(aluno.id)
                    .delete()
                    .await()
            }
        } catch (_: TimeoutCancellationException) {
            throw Exception("timeout: Firebase demorou muito para responder. Verifique sua conexao.")
        } catch (_: Exception) {
            throw Exception("Firebase error")
        }
    }
}