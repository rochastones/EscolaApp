package com.example.escolaapp.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("settings")

class DataStoreManager(private val context: Context) {
    companion object {
        private val DATA_SOURCE_KEY = stringPreferencesKey("data_source")
        private val TOKEN_KEY = stringPreferencesKey("api_token")
        private val USER_ID_KEY = stringPreferencesKey("user_id")
        private val USER_EMAIL_KEY = stringPreferencesKey("user_email")
    }

    // Fonte de dados
    suspend fun saveDataSource(type: DataSourceType) {
        context.dataStore.edit { preferences ->
            preferences[DATA_SOURCE_KEY] = type.name
        }
    }

    fun getDataSourceFlow(): Flow<DataSourceType> {
        return context.dataStore.data.map { preferences ->
            val typeName = preferences[DATA_SOURCE_KEY] ?: DataSourceType.ROOM.name
            DataSourceType.valueOf(typeName)
        }
    }

    // Token JWT
    suspend fun saveToken(token: String) {
        context.dataStore.edit { preferences ->
            preferences[TOKEN_KEY] = token
        }
    }

    suspend fun getToken(): String? {
        return context.dataStore.data.map { preferences ->
            preferences[TOKEN_KEY]
        }.first()
    }

    // Método síncrono para o Interceptor
    fun getTokenSync(): String? {
        return runBlocking {
            context.dataStore.data.map { preferences ->
                preferences[TOKEN_KEY]
            }.first()
        }
    }

    suspend fun saveUserId(userId: String) {
        context.dataStore.edit { preferences ->
            preferences[USER_ID_KEY] = userId
        }
    }

    suspend fun saveUserEmail(email: String) {
        context.dataStore.edit { preferences ->
            preferences[USER_EMAIL_KEY] = email
        }
    }

    suspend fun clearUserData() {
        context.dataStore.edit { preferences ->
            preferences.remove(TOKEN_KEY)
            preferences.remove(USER_ID_KEY)
            preferences.remove(USER_EMAIL_KEY)
        }
    }
}