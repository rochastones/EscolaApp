package com.example.escolaapp.presentation.ui.config

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import com.example.escolaapp.presentation.viewmodel.TransactionViewModel
import com.example.escolaapp.utils.DataSourceType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigScreen(
    viewModel: TransactionViewModel,
    onBack: () -> Unit
) {
    val currentDataSource by viewModel.currentDataSource.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configurações - Fonte de Dados") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Repositório Ativo:",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = when (currentDataSource) {
                                DataSourceType.ROOM -> "📱 LOCAL (Room Database)"
                                DataSourceType.API -> "🌐 REMOTO (API REST + PHP/MySQL)"
                                DataSourceType.FIREBASE -> "☁️ NUVEM (Firebase Firestore)"
                            },
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            item {
                Text(
                    text = "Escolha a origem dos dados:",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            item {
                DataSourceButton(
                    type = DataSourceType.ROOM,
                    isSelected = currentDataSource == DataSourceType.ROOM,
                    onClick = { viewModel.changeDataSource(DataSourceType.ROOM) }
                )
            }

            item {
                DataSourceButton(
                    type = DataSourceType.API,
                    isSelected = currentDataSource == DataSourceType.API,
                    onClick = { viewModel.changeDataSource(DataSourceType.API) }
                )
            }

            item {
                DataSourceButton(
                    type = DataSourceType.FIREBASE,
                    isSelected = currentDataSource == DataSourceType.FIREBASE,
                    onClick = { viewModel.changeDataSource(DataSourceType.FIREBASE) }
                )
            }
        }
    }
}

@Composable
fun DataSourceButton(
    type: DataSourceType,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primary
            else
                MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Text(
            text = when (type) {
                DataSourceType.ROOM -> "📱 Room Database (Local)"
                DataSourceType.API -> "🌐 API REST (PHP/MySQL)"
                DataSourceType.FIREBASE -> "☁️ Firebase Firestore (Nuvem)"
            }
        )
    }
}