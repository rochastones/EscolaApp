package com.example.escolaapp.data.mapper

import com.example.escolaapp.domain.model.Aluno
import com.example.escolaapp.data.datasource.local.AlunoEntity
import com.example.escolaapp.data.datasource.remote.AlunoDto
import com.example.escolaapp.data.datasource.firebase.AlunoFirestoreDto

class AlunoMapper {
    fun toDomain(entity: AlunoEntity): Aluno = Aluno(
        id = entity.id,
        nomeAluno = entity.nomeAluno,
        nomeProfessor = entity.nomeProfessor,
        disciplina = entity.disciplina,
        nota = entity.nota,
        statusAprovacao = entity.statusAprovacao
    )

    fun toEntity(domain: Aluno): AlunoEntity = AlunoEntity(
        id = domain.id,
        nomeAluno = domain.nomeAluno,
        nomeProfessor = domain.nomeProfessor,
        disciplina = domain.disciplina,
        nota = domain.nota,
        statusAprovacao = domain.statusAprovacao
    )

    fun toDomain(dto: AlunoDto): Aluno = Aluno(
        id = dto.id,
        nomeAluno = dto.nomeAluno,
        nomeProfessor = dto.nomeProfessor,
        disciplina = dto.disciplina,
        nota = dto.nota,
        statusAprovacao = dto.statusAprovacao
    )

    fun toDto(domain: Aluno): AlunoDto = AlunoDto(
        id = domain.id,
        nomeAluno = domain.nomeAluno,
        nomeProfessor = domain.nomeProfessor,
        disciplina = domain.disciplina,
        nota = domain.nota,
        statusAprovacao = domain.statusAprovacao
    )

    fun fromFirestoreDto(dto: AlunoFirestoreDto): Aluno = Aluno(
        id = dto.id,
        nomeAluno = dto.nomeAluno,
        nomeProfessor = dto.nomeProfessor,
        disciplina = dto.disciplina,
        nota = dto.nota,
        statusAprovacao = dto.statusAprovacao
    )

    fun toFirestoreDto(domain: Aluno): AlunoFirestoreDto = AlunoFirestoreDto(
        id = domain.id,
        nomeAluno = domain.nomeAluno,
        nomeProfessor = domain.nomeProfessor,
        disciplina = domain.disciplina,
        nota = domain.nota,
        statusAprovacao = domain.statusAprovacao
    )
}