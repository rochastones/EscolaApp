package com.example.escolaapp.utils

import com.example.escolaapp.data.repository.TransactionRepositoryFirebaseImpl
import com.example.escolaapp.data.repository.TransactionRepositoryRemoteImpl
import com.example.escolaapp.data.repository.TransactionRepositoryRoomImpl
import com.example.escolaapp.domain.repository.TransactionRepository

class RepositoryProvider(
    private val roomRepo: TransactionRepositoryRoomImpl,
    private val remoteRepo: TransactionRepositoryRemoteImpl,
    private val firebaseRepo: TransactionRepositoryFirebaseImpl
) {
    fun getRepository(type: DataSourceType): TransactionRepository {
        return when (type) {
            DataSourceType.ROOM -> roomRepo
            DataSourceType.API -> remoteRepo
            DataSourceType.FIREBASE -> firebaseRepo
        }
    }
}