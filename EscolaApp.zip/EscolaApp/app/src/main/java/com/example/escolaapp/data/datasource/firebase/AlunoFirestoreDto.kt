package com.example.escolaapp.data.datasource.firebase

data class AlunoFirestoreDto(
    val id: String = "",
    val nomeAluno: String = "",
    val nomeProfessor: String = "",
    val disciplina: String = "",
    val nota: Double = 0.0,
    val statusAprovacao: String = ""
)