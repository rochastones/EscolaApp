package com.example.escolaapp.presentation.navigation

// Define as rotas de navegação do aplicativo
sealed class Screen(val route: String) {
    // Telas de Autenticação
    object Login : Screen("login")
    object SignUp : Screen("signup")

    // Telas Principais
    object Menu : Screen("menu")
    object Transactions : Screen("transactions")
    object Config : Screen("config")
}