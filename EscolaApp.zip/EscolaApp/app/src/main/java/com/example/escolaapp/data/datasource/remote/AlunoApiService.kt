package com.example.escolaapp.data.datasource.remote

import retrofit2.Call
import retrofit2.Response
import retrofit2.http.*

interface AlunoApiService {

    // ENDPOINTS EXISTENTES (CRUD)
    @GET("get_alunos.php")
    suspend fun getAlunos(): List<AlunoDto>

    @POST("insert_aluno.php")
    suspend fun insertAluno(@Body aluno: AlunoDto)

    @PUT("update_aluno.php")
    suspend fun updateAluno(@Body aluno: AlunoDto)

    @DELETE("delete_aluno.php")
    suspend fun deleteAluno(@Query("id") id: String)

    // ENDPOINT: GERAR TOKEN JWT
    @POST("login_auth.php")
    suspend fun generateToken(@Body request: Map<String, String>): Response<TokenResponseDto>
}