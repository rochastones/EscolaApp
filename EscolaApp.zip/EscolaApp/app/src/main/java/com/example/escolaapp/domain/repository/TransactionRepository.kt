package com.example.escolaapp.domain.repository

import com.example.escolaapp.domain.model.Aluno
import kotlinx.coroutines.flow.Flow

interface TransactionRepository {
    fun getAllAlunos(): Flow<List<Aluno>>
    suspend fun addAluno(aluno: Aluno)
    suspend fun updateAluno(aluno: Aluno)
    suspend fun deleteAluno(aluno: Aluno)
}