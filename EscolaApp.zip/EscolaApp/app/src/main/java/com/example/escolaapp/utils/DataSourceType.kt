package com.example.escolaapp.utils

enum class DataSourceType {
    ROOM,
    API,
    FIREBASE
}