package com.example.escolaapp.data.repository

import com.example.escolaapp.data.datasource.local.AlunoDao
import com.example.escolaapp.data.mapper.AlunoMapper
import com.example.escolaapp.domain.model.Aluno
import com.example.escolaapp.domain.repository.TransactionRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TransactionRepositoryRoomImpl(
    private val dao: AlunoDao,
    private val mapper: AlunoMapper
) : TransactionRepository {

    override fun getAllAlunos(): Flow<List<Aluno>> {
        return dao.getAll().map { entities ->
            entities.map { mapper.toDomain(it) }
        }
    }

    override suspend fun addAluno(aluno: Aluno) {
        dao.insert(mapper.toEntity(aluno))
    }

    override suspend fun updateAluno(aluno: Aluno) {
        dao.update(mapper.toEntity(aluno))
    }

    override suspend fun deleteAluno(aluno: Aluno) {
        dao.delete(mapper.toEntity(aluno))
    }
}